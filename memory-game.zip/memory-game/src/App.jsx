import { useEffect, useReducer, useState } from 'react'
import './App.css'
import Deck from './deck';

const cardImages = [
  { "src": "/img/helmet-1.png", matched: false },
  { "src": "/img/potion-1.png", matched: false },
  { "src": "/img/ring-1.png", matched: false },
  { "src": "/img/scroll-1.png", matched: false },
  { "src": "/img/shield-1.png", matched: false },
  { "src": "/img/sword-1.png", matched: false }
]
const initialState = {
  clickedCards: [],
  matchedCards: [],
  turns: 0
};


function App() {
  // const [Clickedcards, setclickcard] = useState(initialState);

  // const handleChoice = (card) => {

  //   setclickcard((prevState) => {
  //     const updatedClickedCards = [...prevState.clickedCards, card];

  //     if (updatedClickedCards.length === 2) {
  //       if (updatedClickedCards[0].src === updatedClickedCards[1].src) {
  //         return {
  //           ...prevState,
  //           matchedCards: [...prevState.matchedCards, ...updatedClickedCards],
  //           clickedCards: [],
  //           turns: prevState.turns + 1
  //         };
  //       }
  //       return { ...prevState, clickedCards: [], turns: prevState.turns + 1 };
  //     }

  //     return { ...prevState, clickedCards: updatedClickedCards };
  //   });

  // }
  // console.log(`matched cards are: ${Clickedcards.matchedCards.map((c) => (c.src))}`);
  // useEffect(() => { console.log(`Clicked cards after are: ${Clickedcards.clickedCards.map((c) => (c.src))}`) }, [Clickedcards.clickedCards]);


  const [cards, setCards] = useState([]);
  const [turn, setTurns] = useState(0);
  const [cardOne, setCardOne] = useState(null);
  const [cardTwo, setCardTwo] = useState(null);
  const [disabled, setDisabled] = useState();
  const handleChoice = (card) => {
    cardOne ? setCardTwo(card) : setCardOne(card)
  }
  useEffect(() => {

    if (cardOne && cardTwo) {
      setDisabled(true);
      if (cardOne.src === cardTwo.src) {
        setCards((prevCards) => {
          return prevCards.map((card) => {
            if (card.src === cardOne.src) {
              return { ...card, matched: true }
            } else {
              return card
            }
          })
        })
        resetTurn();
      } else {
        setTimeout(() => resetTurn(), 1000);

      }
    }
  }, [cardOne, cardTwo]);

  console.log(cards);

  useEffect(() => {
    shuffleCards();
  }, [])
  const resetTurn = () => {
    setCardOne(null);
    setCardTwo(null);
    setTurns((prevState) => prevState + 1);
    setDisabled(false);
  }
  const shuffleCards = () => {
    const shuffledCards = [...cardImages, ...cardImages].sort(() => Math.random() - 0.5)
      .map((card) => ({ ...card, id: Math.random() }))
    setCardOne(null);
    setCardTwo(null);
    setCards(shuffledCards);

  }
  const flipped = (card) => {
    return card === cardOne || card === cardTwo || card.matched
  }
  return (
    <div className='app'>
      <h1>Memory Game</h1>
      <button onClick={shuffleCards}>New Game</button>
      <Deck Cards={cards} handler={handleChoice} flipped={flipped} disabled={disabled}></Deck>
      <h1>Turns: {turn}</h1>
    </div>
  )
}

export default App
