const Card = ({ card, handler, flipped, disable }) => {
    return <div className="card">
        <div className={`${flipped ? 'flipped' : ""}   card-image`}>
            <img className="front" src={card.src} alt="front-cover" ></img>
            <img className="back" src="/img/cover.png" alt="back-cover" onClick={() => disable ? '' : handler(card)}></img>
        </div>
    </div>
}

export default Card