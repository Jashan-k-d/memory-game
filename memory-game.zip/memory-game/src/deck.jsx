import Card from "./card"

const Deck = ({ Cards, handler, flipped, disabled }) => {
    return <>

        <div className="deck">
            {Cards.map((card) => (<Card card={card} key={card.id} handler={handler} flipped={flipped(card)} disable={disabled}></Card>))}
        </div>
    </>
}

export default Deck;